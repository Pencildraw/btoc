<?php
namespace app\controller;

use app\BaseController;
use http\Params;
use think\Facade\Db;
use think\Request;

class User extends BaseController
{

//    用户全部
    public function user_all(){

        $data = input("param.");
//        页数 page
        $page = !empty($data['page'])? $data['page']:0;
        $page_number = !empty($data['page_number'])? $data['page_number']:0;
        $row  = DB::table('xy_user')
            ->alias('u')
//            ->limit($page,$page_number)
            ->join('xy_userlevel l','u.userlevel_id = l.userlevel_id')
//            ->join('xy_order o','u.user_id = o.user_id')
            ->field('u.* ,l.userlevel_name ')
            ->order('u.user_id')
            ->select();

//        预防无法重载 设置中间变量
        $row = $row->all();
        foreach ($row as $key => $value){
            $row[$key]['order_sum'] = DB::table('xy_order')
                ->where(['user_id'=>$value['user_id']])->count();
//            dump($row[$key]); die();
        }

        return json([
            'data'=>$row,
            'code'=>200,
            'msg'=>'操作成功'
        ]);
    }

//    用户详情
    public function user_id(){
        $data = input('param.');
        if (empty($data['user_id'])){
            return json([
                'data'=>'',
                'code'=>10001,
                'msg'=>'缺少用户ID'
            ]);
        }
        $row = DB::table('xy_user')
            ->alias('u')
            ->where(['u.user_id'=>$data['user_id']])
            ->join('xy_userlevel l','u.userlevel_id = l.userlevel_id')
            ->join('xy_order o','u.user_id = o.user_id')
            ->field('u.* ,l.userlevel_name ,count(o.order_id) as order_sum')
            ->order('u.user_id')
            ->select();
        return json([
            'data'=>$row,
            'code'=>200,
            'msg'=>'操作成功'
        ]);
    }




}
