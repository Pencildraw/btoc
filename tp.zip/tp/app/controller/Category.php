<?php
namespace app\controller;

use app\BaseController;
use http\Params;
use think\Facade\Db;
use think\Request;

class Category extends BaseController
{

//    类别全部
    public function category_all(){
//        主层 类别
        $where = array(
            'category_pid'=>0,
        );
        $data = input('param.');
        if (!empty($data['category_id'])){
            $where = array(
                'category_id'=>$data['category_id'],
            );
        }

        $res  = DB::table('xy_category')
            ->where($where)
            ->order('category_order')
            ->select();
        if(!empty($res)){

            foreach ($res AS $k=>$v)
            {
                $cat_class[$k]['category_id']   = $v['category_id'];
                $cat_class[$k]['category_name'] = $v['category_name'];
                $cat_class[$k]['category_pid']   = $v['category_pid'];
                $getSon = $this->get_child_tree($v['category_id'],1);
                if ($getSon)
                {
                    $cat_class[$k]['three_class'] = $this->get_child_tree($v['category_id']);
                }
            }
        }
//        dump($cat_class); die();
        return json([
            'data'=>$cat_class,
            'code'=>200,
            'msg'=>'操作成功'
        ]);
    }

//  获取当前分类下的子分类（不包括自己）
    public  function get_child_tree($tree_id,$get=0)
    {

        $two_arr = array();
        $res = Db::name('xy_category')->where('category_pid',$tree_id)
            ->order('category_order')
            ->select();

        if($get && empty($res)){
            return false;
        }
        foreach ($res AS $k=>$v)
        {
            $two_arr[$k]['category_id']   = $v['category_id'];
            $two_arr[$k]['category_name_son'] = $v['category_name'];
            $two_arr[$k]['category_pid']   = $v['category_pid'];

            $getSon = $this->get_child_tree($v['category_id'],1);
            if ($getSon){
                $two_arr[$k]['three_class'] = $this->get_child_tree($v['category_id']);
            }

        }
        return $two_arr;
    }


}
