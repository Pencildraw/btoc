<?php
namespace app\controller;

use app\BaseController;
use http\Params;
use think\Facade\Db;
use think\Request;

class Brand extends BaseController
{

//    品牌全部
    public function brand_all(){

        $data = input("param.");
//        页数 page
        $page = !empty($data['page'])? $data['page']:0;
        $page_number = !empty($data['page_number'])? $data['page_number']:0;
        $row  = DB::table('xy_brand')
            ->limit($page,$page_number)
            ->order('brand_order')
            ->select();

        foreach ($row as $key => $value){
            if (!empty($row)){
                $row[$key] = $this->completion($value);
            }
        }

        return json([
            'data'=>$row,
            'code'=>200,
            'msg'=>'操作成功'
        ]);
    }

//    商品详情
    public function brand_id(){
        $data = input('param.');
        if (empty($data['brand_id'])){
            return json([
                'data'=>'',
                'code'=>10001,
                'msg'=>'缺少品牌ID'
            ]);
        }
        $row = DB::table('xy_brand')
            ->where(['brand_id'=>$data['brand_id']])
            ->find();
        if (!empty($row)){
            $row = $this->completion($row);
        }
        return json([
            'data'=>$row,
            'code'=>200,
            'msg'=>'操作成功'
        ]);
    }

    //    补全信息
    public function completion($row = array()){

//        补全 图片路径
        $row['brand_logo'] = !empty($row['brand_logo'])? PRODUCT_LOGO.$row['brand_logo']: '';
//        dump($row); die();
        return $row;

    }



}
