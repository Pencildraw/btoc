<?php
namespace app\controller;

use app\BaseController;
use http\Params;
use think\Facade\Db;
use think\Request;

class Product extends BaseController
{

//    商品全部
    public function product_all(){
        $data = input("param.");
        $where = array(
            'product_state'=>1,
        );
//        种类 category_id
        if (!empty($data['category_id'])){
            $where['category_id'] = $data['category_id'];
        }
//        当前页数 page     总页数 page_count
//         总数 page_sum      页面显示数量 page_number
        $page = !empty($data['page'])? ($data['page']-1):0;
        $page_number = !empty($data['page_number'])? $data['page_number']:0;
        $page = $page*$page_number;
        $row  = DB::table('xy_product')
            ->where($where)
            ->limit($page,$page_number)
            ->select();
        $page_sum = DB::table('xy_product')
            ->where($where)
            ->count();
        $page_count = intval(ceil($page_sum/$page_number));
//        dump($page,$page_sum,$page_number,$page_count) ;die();
        $pages = array(
            'page'=>$page,
            'page_count'=>$page_count,
        );
        foreach ($row as $key => $value){
            if (!empty($row)){
                $row[$key] = $this->product_completion($value);
            }
        }

        return json([
            'data'=>$row,
            'code'=>200,
            'msg'=>'操作成功',
            'page'=>$pages,
        ]);
    }

//    商品详情
    public function product_id(){
        $data = input('param.');
        if (empty($data['product_id'])){
            return json([
                'data'=>'',
                'code'=>10001,
                'msg'=>'缺少商品ID'
            ]);
        }
        $row = DB::table('xy_product')
            ->where(['product_id'=>$data['product_id']])
            ->find();
        if (!empty($row)){
            $row = $this->product_completion($row);
        }
        return json([
            'data'=>$row,
            'code'=>200,
            'msg'=>'操作成功'
        ]);
    }

//    补全商品信息
    public function product_completion($row = array()){

        $brand = DB::table('xy_brand')->where(['brand_id'=>$row['brand_id']])->find();
        $category = DB::table('xy_category')->where(['category_id'=>$row['category_id']])->find();
//        补全 类别/品牌名称
        $row['brand_name'] = !empty($brand['brand_name'])? $brand['brand_name']: '';
        $row['category_name'] = !empty($category['category_name'])? $category['category_name']: '';
//        补全 图片路径
        $row['product_logo'] = !empty($row['product_logo'])? PRODUCT_LOGO.$row['product_logo']: '';
        $row['product_album'] = !empty($row['product_album'])? PRODUCT_ALBUM.$row['product_album']: '';
//        反序列化 规格数据集
        $row['product_rule'] = !empty($row['product_album'])? unserialize($row['product_rule']): '';
        return $row;
//        dump($row); die();

    }


}
