<?php
namespace app\controller;

use app\BaseController;
use http\Params;
use think\Facade\Db;
use think\Request;

class Rule extends BaseController
{

//    规格全部
    public function rule_all(){
        $data = input("param.");
//        页数 page
        $page = !empty($data['page'])? $data['page']:0;
        $page_number = !empty($data['page_number'])? $data['page_number']:0;
        $row  = DB::table('xy_rule')
            ->limit($page,$page_number)
            ->select();
        foreach ($row as $key => $value){
            if (!empty($row)){
                $row[$key] = $this->completion($value);
            }
        }

        return json([
            'data'=>$row,
            'code'=>200,
            'msg'=>'操作成功'
        ]);
    }

//    规格详情
    public function rule_id(){
        $data = input('param.');
        if (empty($data['rule_id'])){
            return json([
                'data'=>'',
                'code'=>10001,
                'msg'=>'缺少规格ID'
            ]);
        }
        $row = DB::table('xy_rule')
            ->where(['rule_id'=>$data['rule_id']])
            ->find();
        if (!empty($row)){
            $row = $this->completion($row);
        }
        return json([
            'data'=>$row,
            'code'=>200,
            'msg'=>'操作成功'
        ]);
    }

    //    规格数据详情
    public function ruledata_id(){
        $data = input('param.');
        if (empty($data['ruledata_id'])){
            return json([
                'data'=>'',
                'code'=>10001,
                'msg'=>'缺少规格数据ID'
            ]);
        }
        $row = DB::table('xy_ruledata')
            ->where(['ruledata_id'=>$data['ruledata_id']])
            ->find();
        return json([
            'data'=>$row,
            'code'=>200,
            'msg'=>'操作成功'
        ]);
    }

//    补全规格信息
    public function completion($row = array()){

        $rule_data = DB::table('xy_ruledata')->where(['rule_id'=>$row['rule_id']])->select();
        $row['rule_data'] = $rule_data;
        return $row;
//        dump($row); die();

    }


}
