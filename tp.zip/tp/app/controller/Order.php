<?php
namespace app\controller;

use app\BaseController;
use http\Params;
use think\Facade\Db;
use think\Request;

class Order extends BaseController
{

//    订单全部
    public function order_all(){

        $data = input("param.");
//        页数 page
        $page = !empty($data['page'])? $data['page']:0;
        $page_number = !empty($data['page_number'])? $data['page_number']:0;
        $row  = DB::table('xy_order')
            ->limit($page,$page_number)
//            ->order('brand_order')
            ->select();

        return json([
            'data'=>$row,
            'code'=>200,
            'msg'=>'操作成功'
        ]);
    }

//    商品详情
    public function order_id(){
        $data = input('param.');
        if (empty($data['order_id'])){
            return json([
                'data'=>'',
                'code'=>10001,
                'msg'=>'缺少订单ID'
            ]);
        }

        $row = DB::table('xy_order')
            ->where(['order_id'=>$data['order_id']])
            ->find();

        return json([
            'data'=>$row,
            'code'=>200,
            'msg'=>'操作成功'
        ]);
    }



}
